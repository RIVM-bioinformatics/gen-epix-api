from gen_epix.omopdb.repositories.omop_dict import (
    OmopDictRepository as OmopDictRepository,
)
from gen_epix.omopdb.repositories.omop_sa import OmopSARepository as OmopSARepository
from gen_epix.omopdb.repositories.organization_dict import (
    OrganizationDictRepository as OrganizationDictRepository,
)
from gen_epix.omopdb.repositories.organization_sa import (
    OrganizationSARepository as OrganizationSARepository,
)
from gen_epix.omopdb.repositories.system_dict import (
    SystemDictRepository as SystemDictRepository,
)
from gen_epix.omopdb.repositories.system_sa import (
    SystemSARepository as SystemSARepository,
)
